﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Git.ViewModels.Repositories
{
    public class RepositoryCreateInputModel
    {
        public string Name { get; set; }

        public string RepositoryType { get; set; }
    }
}
